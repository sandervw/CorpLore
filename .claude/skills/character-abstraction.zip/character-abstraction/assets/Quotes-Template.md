# [CHARACTER NAME] — Quotes

_[Work Title] by [Author/Creator]_

## Original

1. Quotes
2. Quotes
3. Quotes

## Abstractd

### Quote 1

**Structure:** [5-15 words describing rhetorical skeleton]

**Rhetorical DNA:**
- [Rhythm/length pattern]
- [Key device or contrast]
- [Register and tone]

**Respecification Seed:** [5-15 words describing dramatic situation]

---

### Quote 2

...