# [Character] — Abstractd Actions

_Source: [Original Work]_

## Original Actions

1. [Original action 1]
2. [Original action 2]
...

## Abstractd Actions

1. [5-10 word abstractd version of action 1]
2. [5-10 word abstractd version of action 2]
...