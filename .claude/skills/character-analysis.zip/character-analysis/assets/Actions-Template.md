# [CHARACTER NAME] — Actions

_[Work Title] by [Author/Creator]_

1. Action
2. Action
3. Action
