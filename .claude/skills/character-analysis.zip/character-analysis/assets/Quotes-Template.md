# [CHARACTER NAME] — Quotes

_[Work Title] by [Author/Creator]_

1. Quotes
2. Quotes
3. Quotes
