# Folklore: [OBJECT/PHENOMENON NAME]

## Source Object/Phenomenon

[Brief description of the input object or phenomenon]

---

## Belief

[The core assertion—what people believe about this object/phenomenon]

---

## Ritual

[The practice that emerges from or reinforces the belief]

---

## Folk Explanation

[The "just-so story" explaining why the belief is true]

---

## Expansion Path

[5-8 numbered stages showing how this belief might evolve over time]

1. **[Stage Name]**: [Description]
2. **[Stage Name]**: [Description]
3. **[Stage Name]**: [Description]
4. **[Stage Name]**: [Description]
5. **[Stage Name]**: [Description]

---

*Generated via folklore-generator skill*
