# [CHARACTER NAME] — Dialogue

_[Work Title] by [Author/Creator]_

## Original

1. Exchange
2. Exchange
3. Exchange

## Abstracted

### Exchange 1

**Word Count:** [bucket]

**Exchange Type:** [Interrogation/Negotiation/Revelation/Confrontation/Counsel/Ritual]

**Tension Arc:** [Escalate/Release/Maintain]

**Beat Count:** [bucket]

**Exchange Shape:** [5-15 words describing thrust-parry pattern]

**Structure:** [5-30 words describing beat progression and interstitial guidance]

**Rhetorical DNA:**
- [Power dynamic]
- [Line length/rhythm contrast]
- [Interstitial action style]

**Respecification Seed:** [5-15 words describing dramatic situation]

---

### Exchange 2

...
