# [CHARACTER NAME] — Paragraphs

_[Work Title] by [Author/Creator]_

## Original

1. Paragraph
2. Paragraph
3. Paragraph

## Abstractd

### Paragraph 1

**Word Count:** [bucket]

**Type:** [Action/Description/Exposition/Reflection/Dialogue]

**Tension Arc:** [Escalate/Release/Maintain]

**Structure:** [5-30 words describing sentence variation and rhetorical skeleton]

**Rhetorical DNA:**
- [Rhythm/length pattern]
- [Key device or contrast]
- [Register and tone]

**Respecification Seed:** [5-15 words describing dramatic situation]

---

### Paragraph 2

...
