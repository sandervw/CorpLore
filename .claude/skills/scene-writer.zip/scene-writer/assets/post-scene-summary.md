# [Storyname]: Scene [X] - Post-Scene Summary

## Scene Summary

[Text]

## Questions Posed

- [Unresolved thread or tension that carries forward]
- [...]

## Characters Introduced or Referenced

**[Character Name]:** [Physical/Personality Description]

## Reflection

**What worked:** [Text]

**What was cut in review:** [Text]

**What's missing:** [Text]
