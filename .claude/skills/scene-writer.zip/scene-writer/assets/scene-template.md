# [Storyname]: Scene [X]

## Full Scene

[Complete scene prose — setup, conflict, and resolution combined as continuous text. Do not include phase subheaders.]
